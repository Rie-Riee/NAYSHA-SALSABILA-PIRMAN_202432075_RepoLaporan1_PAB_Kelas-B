import 'package:flutter/material.dart';

// 1. DATA MODEL (Minimal 3 field & 3 tipe data berbeda) NAYSHA SALSABILA PIRMAN_202432075
class CompanionCharacter {
  final String name;      // Tipe 1: String
  final int health;        // Tipe 2: int
  final double energy;     // Tipe 3: double
  final bool isHappy;      // Tipe 4: bool

  const CompanionCharacter({
    required this.name,
    required this.health,
    required this.energy,
    required this.isHappy,
  });
}

void main() {
  runApp(const MyApp());
}

// 2. MYAPP DENGAN THEME SAGE GREEN SCRAPBOOK NAYSHA SALSABILA PIRMAN_202432075
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Journal & Well-Being',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFD4E3DC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF78A18B),
          primary: const Color(0xFF4A705B),
          secondary: const Color(0xFF9EBFAD),
        ),
      ),
      home: const CompanionDashboardPage(),
    );
  }
}

// 3. HALAMAN UTAMA (STATEFUL WIDGET UNTUK INTERAKSI TOMBOL) naysha salsabila pirman_202432075
class CompanionDashboardPage extends StatefulWidget {
  const CompanionDashboardPage({super.key});

  @override
  State<CompanionDashboardPage> createState() => _CompanionDashboardPageState();
}

class _CompanionDashboardPageState extends State<CompanionDashboardPage> {
  // Data dummy karakter
  final CompanionCharacter character = const CompanionCharacter(
    name: 'Vyn Richter',
    health: 90,
    energy: 45.0,
    isHappy: true,
  );

  // Dialog Vyn Richter
  final List<String> _dialogList = [
    'I heard a new gelato stall opened near the central plaza today. They say the pistachio flavor is quite exquisite... Shall we try it together later? 🍦✨',
    'The mint plant on my study balcony has sprouted new leaves this morning. Plants truly respond well to quiet, attentive care... much like human minds. 🌿',
    'I finished reviewing the latest case file for NXX. The psychological motives are clearer now. You need not worry; everything is proceeding smoothly. 🔍',
    'I stumbled upon an intriguing rare literature on behavioral psychology during my break. I would love to share a few chapters with you if you have time. 📖',
    'Good day. I see you are quite occupied today. Remember that productivity requires a calm mind. Allow me to brew a cup of Earl Grey tea for us. ☕',
    'Have you taken enough water today? Maintaining your physical well-being is not merely a task, but a vital foundation for clarity of thought. 💧',
    'Human emotions are like delicate threads. You have worked admirably today, so leave the remaining burdens to time and allow yourself proper rest. ✨',
    'You are pushing yourself past your physical limits again, aren\'t you? Do not test my patience with self-neglect. Sleep now, or I shall intervene. 🗯️',
  ];

  // Path gambar NAYSHA SALSABILA PIRMAN_202432075
  final List<String> _characterImages = [
    'assets/vyn_gelato.jpg',
    'assets/vyn_plant.jpg',
    'assets/vyn_serious.jpg',
    'assets/vyn_book.jpg',
    'assets/vyn_tea.jpg',
    'assets/vyn_drink.jpg',
    'assets/vyn_calm.jpg',
    'assets/vyn_stern.jpg',
  ];

  final List<String> _expressionLabels = [
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
    'NAYSHA SALSABILA PIRMAN_202432075',
  ];

  int _currentIndex = 0;

  // Callback tombol interaksi + LOG AKTIVITAS CONSOLEV NAYSHA SALSABILA PIRMAN_202432075
  void _nextInteraction() {
    setState(() {
      _currentIndex = (_currentIndex + 1) % _dialogList.length;
    });

    // PENCATATAN LOG KE CONSOLE BROWSER
    debugPrint('[LOG APP] Button clicked! Changing index to: $_currentIndex');
    debugPrint('[LOG APP] Active Talk Label: ${_expressionLabels[_currentIndex]}');
    debugPrint('[LOG APP] Dialog Text: ${_dialogList[_currentIndex]}');

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.auto_awesome, color: Colors.white, size: 18),
            const SizedBox(width: 8),
            Text('${character.name}\'s response updated!'),
          ],
        ),
        backgroundColor: const Color(0xFF4A705B),
        duration: const Duration(milliseconds: 600),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '📖 Daily Journal & Well-Being 📖',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color(0xFF2C4335),
            fontSize: 18,
            letterSpacing: 1.1,
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFB3CDC0),
        elevation: 0,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 16.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Container(
              padding: const EdgeInsets.all(20.0),
              decoration: BoxDecoration(
                color: const Color(0xFFFFFDF9),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: const Color(0xFF4A705B), width: 3),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0xFF4A705B),
                    offset: Offset(6, 6),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // HEADER TANGGAL & WAKTU
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE1EFEB),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFF4A705B), width: 2),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.calendar_today_rounded, size: 14, color: Color(0xFF4A705B)),
                            SizedBox(width: 6),
                            Text('OCTOBER 20', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF2C4335))),
                          ],
                        ),
                        Row(
                          children: [
                            Icon(Icons.access_time_rounded, size: 14, color: Color(0xFF4A705B)),
                            SizedBox(width: 6),
                            Text('02:00 PM', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11, color: Color(0xFF2C4335))),
                          ],
                        ),
                        Icon(Icons.eco_rounded, color: Color(0xFF4A705B), size: 18),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // STATUS & AVATAR FRAME
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 5,
                        child: StatCardWidget(character: character),
                      ),
                      const SizedBox(width: 12),

                      Expanded(
                        flex: 6,
                        child: Container(
                          height: 270,
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: const Color(0xFFC3D8CE),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: const Color(0xFF4A705B), width: 2.5),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(14),
                                  child: Image.asset(
                                    _characterImages[_currentIndex],
                                    fit: BoxFit.cover,
                                    width: double.infinity,
                                    errorBuilder: (context, error, stackTrace) {
                                      return Container(
                                        color: const Color(0xFF9EBFAD),
                                        child: const Center(
                                          child: Icon(
                                            Icons.person_rounded,
                                            size: 50,
                                            color: Color(0xFF2C4335),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF4A705B),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  _expressionLabels[_currentIndex],
                                  style: const TextStyle(color: Colors.white, fontSize: 8.0, fontWeight: FontWeight.bold),
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // DAILY QUEST SECTION
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3F8F5),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFF78A18B), width: 2),
                      boxShadow: const [
                        BoxShadow(color: Color(0xFFB3CDC0), offset: Offset(3, 3)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.assignment_turned_in_rounded, size: 18, color: Color(0xFF4A705B)),
                            SizedBox(width: 8),
                            Text(
                              'SPECIAL EVENT & DAILY QUESTS',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: Color(0xFF2C4335),
                                letterSpacing: 0.8,
                              ),
                            ),
                          ],
                        ),
                        const Divider(color: Color(0xFF9EBFAD), height: 16, thickness: 1.5),
                        _buildQuestItem('Try the new gelato stall at Central Plaza 🍦', true),
                        const SizedBox(height: 6),
                        _buildQuestItem('Review NXX Investigation files & notes 🔍', true),
                        const SizedBox(height: 6),
                        _buildQuestItem('Complete Mobile Programming Lab Report 1 📑', false),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // VISUAL NOVEL DIALOG BOX
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFF4A705B), width: 2.5),
                      boxShadow: const [
                        BoxShadow(color: Color(0xFF4A705B), offset: Offset(4, 4)),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.bookmark_rounded, color: Color(0xFF4A705B), size: 18),
                            const SizedBox(width: 6),
                            Text(
                              character.name.toUpperCase(),
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 13.5,
                                color: Color(0xFF2C4335),
                                letterSpacing: 1.0,
                              ),
                            ),
                          ],
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8.0),
                          child: Divider(color: Color(0xFF9EBFAD), thickness: 1.5),
                        ),
                        Text(
                          _dialogList[_currentIndex],
                          style: const TextStyle(
                            fontSize: 13.0,
                            color: Color(0xFF2C4335),
                            height: 1.5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),

                  // TOMBOL BICARA
                  ElevatedButton(
                    onPressed: _nextInteraction,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4A705B),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(color: Color(0xFF2C4335), width: 2),
                      ),
                      elevation: 0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.forum_rounded, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'Talk to ${character.name}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Helper widget checklist Daily Quest
  Widget _buildQuestItem(String title, bool isDone) {
    return Row(
      children: [
        Icon(
          isDone ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded,
          size: 16,
          color: isDone ? const Color(0xFF4A705B) : Colors.grey,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 11.5,
              color: const Color(0xFF2C4335),
              decoration: isDone ? TextDecoration.lineThrough : TextDecoration.none,
              decorationColor: const Color(0xFF4A705B),
            ),
          ),
        ),
      ],
    );
  }
}

// 4. CUSTOM WIDGET MEMAKAI CARD WIDGET (Sesuai Persyaratan Soal Praktikum)
class StatCardWidget extends StatelessWidget {
  final CompanionCharacter character;

  const StatCardWidget({super.key, required this.character});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF4A705B), width: 2),
      ),
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'WELL-BEING',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 11,
                color: Color(0xFF2C4335),
              ),
            ),
            const SizedBox(height: 8),

            // HP Bar
            Row(
              children: [
                const Icon(Icons.favorite_rounded, color: Color(0xFFD97762), size: 14),
                const SizedBox(width: 4),
                Text(
                  'HP: ${character.health}/100',
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: character.health / 100,
                backgroundColor: const Color(0xFFFADCD5),
                color: const Color(0xFFD97762),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 8),

            // Energy Bar
            Row(
              children: [
                const Icon(Icons.bolt_rounded, color: Color(0xFFE9C46A), size: 14),
                const SizedBox(width: 4),
                Text(
                  'Energy: ${character.energy.toInt()}/50',
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: character.energy / 50,
                backgroundColor: const Color(0xFFFDF0CD),
                color: const Color(0xFFE9C46A),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 8),

            // Mood Status
            Row(
              children: [
                Icon(
                  character.isHappy
                      ? Icons.sentiment_very_satisfied_rounded
                      : Icons.sentiment_neutral_rounded,
                  color: const Color(0xFF4A705B),
                  size: 14,
                ),
                const SizedBox(width: 4),
                Text(
                  character.isHappy ? 'Mood: Peaceful' : 'Mood: Calm',
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF2C4335),
                  ),
                ),
              ],
            ),

            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6.0),
              child: Divider(color: Color(0xFF9EBFAD), thickness: 1),
            ),

            // 1. QUICK REMINDERS (Self-Care Loggers) - BEBAS OVERFLOW
            const Text(
              'QUICK REMINDERS',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 9.0,
                color: Color(0xFF4A705B),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildTrackerChip(context, Icons.water_drop_rounded, 'Water', 'Hydration logged! +10 HP 💧'),
                _buildTrackerChip(context, Icons.restaurant_rounded, 'Meal', 'Balanced meal logged! +15 Energy 🥗'),
                _buildTrackerChip(context, Icons.bedtime_rounded, 'Sleep', 'Rest hours logged with Vyn! 😴'),
              ],
            ),

            const Padding(
              padding: EdgeInsets.symmetric(vertical: 6.0),
              child: Divider(color: Color(0xFF9EBFAD), thickness: 1),
            ),

            // 2. MAIN FEATURE SHORTCUTS (Journal, Events, Mood) - BEBAS OVERFLOW
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildFeatureButton(context, Icons.edit_note_rounded, 'Journal', 'Opening Daily Reflection Journal... 📝'),
                _buildFeatureButton(context, Icons.calendar_month_rounded, 'Events', 'Checking Calendar & NXX Schedule... 📅'),
                _buildFeatureButton(context, Icons.psychology_alt_rounded, 'Mood', 'Opening Mood Tracker & Trends... 💭'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Helper Widget untuk Quick Reminder Chips (Flexible & Bebas Overflow)
  Widget _buildTrackerChip(BuildContext context, IconData icon, String label, String snackMessage) {
    return Flexible(
      child: InkWell(
        onTap: () => _showSnack(context, snackMessage),
        borderRadius: BorderRadius.circular(6),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 3),
          decoration: BoxDecoration(
            color: const Color(0xFFF3F8F5),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: const Color(0xFF78A18B), width: 1),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 9, color: const Color(0xFF4A705B)),
              const SizedBox(width: 2),
              Flexible(
                child: Text(
                  label,
                  style: const TextStyle(fontSize: 7.0, fontWeight: FontWeight.w600, color: Color(0xFF2C4335)),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper Widget untuk Feature Buttons (Flexible & Bebas Overflow)
  Widget _buildFeatureButton(BuildContext context, IconData icon, String label, String snackMessage) {
    return Flexible(
      child: InkWell(
        onTap: () => _showSnack(context, snackMessage),
        borderRadius: BorderRadius.circular(8),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: const Color(0xFFE1EFEB),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF4A705B), width: 1),
              ),
              child: Icon(icon, size: 12, color: const Color(0xFF2C4335)),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(
                fontSize: 7.0,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2C4335),
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ],
        ),
      ),
    );
  }

  void _showSnack(BuildContext context, String message) {
    debugPrint('[LOG APP] Quick Feature Action clicked: $message');
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF4A705B),
        duration: const Duration(milliseconds: 800),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}